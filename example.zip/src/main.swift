import Foundation

struct Greeter {
    let name: String
    func hello() -> String { "Hello, \(name)!" }
}
