# Example Archive

This zip is a **preview test** for Sidewatch.

## Structure
- src/
- docs/
- config/

## Notes
Double-click any file to preview it.
